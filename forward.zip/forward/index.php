<!DOCTYPE html>
<html lang="en" class="full-screen">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>I Am More</title>
  <!--Favicon-->
  <link rel="shortcut icon" href="./img/favicon.ico" type="image/x-icon">
  <!-- Lato GoogleFont-->
  <link href='http://fonts.googleapis.com/css?family=Lato:400,700' rel='stylesheet' type='text/css'>
  <!-- Font Awesome-->
  <link href="font/font-awesome-4.7.0/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet">
  <!-- Bootstrap core css-->
  <link type="text/css" rel="stylesheet" href="./css/bootstrap.min.css" media="screen,projection" />
  <!-- Material Design Bootstrap -->
  <link type="text/css" rel="stylesheet" href="./css/mdb.min.css" media="screen,projection" />
  <link type="text/css" rel="stylesheet" href="./css/mdb.lite.min.css" media="screen,projection" />
  <!-- My custom css -->
  <link type="text/css" rel="stylesheet" href="./css/style.css" media="screen,projection" />
  <script type="text/javascript" src="https://connect.facebook.net/en_US/sdk.js"></script>

</head>

<body class="home">
  <section id="home">
    <header class="clearfix">
      <div class=" container">
        <!-- logos -->
        <div id="logos" class="pull-right">
          <div class="navbar-brand">
            <a href="index.php">
              <img src="img/new-accesslogo.png" alt="New Access Logo" />
            </a>
          </div>
          <!-- <div class="navbar-brand"><img src="img/diamondlogo.png" alt="Diamond Logo" /></div> -->
        </div>
      </div>
    </header>
    <section id="banner">
      <div class="container">
        <div class="content">
          <h1>MORE THAN A <span>BANKER</span></h1>
          <h2>Banker during the week, band player by weekend.</h2>
          <p>
            We understand that everyone’s hustle is different and no one
            can tell your story better than you. That is why the
            #Morethan app was created for you! This app enables you to
            tell the story of your two hustles using pictures.
          </p>
          <a href="#start" id="start-scroll" class="btn btn-start">Get started</a>
        </div>
      </div>
    </section>
  </section>
  <section id="start">
    <div class="row">
      <div class="col-12 col-sm-12">
        <!-- Offset -->
        <div id="form-step-wrap">
          <form id="morethan" action="success.php" method="post" enctype="multipart/form-data">
            <fieldset>
              <div id="step1box" class="slider-step first-step step" data-next-step="step-main-hustle">
                <div class="row tall">
                  <div class="col-12 form-intro">
                    <div class="row">
                      <div class="col-12 col-sm-6">
                        <p>Here are the steps:<p>
                            <ol>
                              <li>1) Enter your full name and email address</li>
                              <li>2) Upload an image of you doing your main hustle</li>
                              <li>3) Type in what your main hustle is e.g. Doctor</li>
                              <li>4) Upload an image of you doing your side hustle</li>
                              <li>5) Type in what your side hustle is e.g. Farmer</li>
                            </ol>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-12 col-sm-6">
                        <input type="text" name="fname" placeholder="First name" tabindex="1" class="form-control">
                        <input type="text" name="lname" placeholder="Last Name" tabindex="2" class="form-control">
                        <input type="email" name="email" placeholder="Email address" tabindex="3" class="form-control">
                        <p id="error1"></p>
                      </div>
                    </div>
                  </div>
                  <!-- /Form Intro -->
                </div>
                <!-- /Row -->
                <div class="row call-to-action">

                  <div class="col-xs-12">
                    <a id="complete1" class="btn btn-next btn-orange">Continue</a>
                  </div>
                </div>
              </div>
            </fieldset>
            <fieldset>
              <!-- Main Hustle -->
              <div id="step-main-hustle" class="slider-step step" data-next-step="step-side-hustle"
                data-back-to="step1box">
                <div class="row">
                  <div class="col-12 col-sm-6 ">
                    <div class="file-upload-wrapper">
                      <h3>Main hustle</h3>
                      <div class="image-upload">
                        <div id="main-hustle-prev-case">
                          <img id="main-hustle-prev" src="#" alt="Your Main Hustle Image" />
                        </div>
                        <label for="input-file-main-hustle">
                          <div>
                            <img src="./img/icon-upload.png" alt="Upload Icon">
                            <p>Add your image here or <span>browse</span></p>
                          </div>
                        </label>
                        <input type="file" name="main_hustle" id="input-file-main-hustle" class="file-upload"
                          tabindex="4" />
                      </div>
                      <input type="text" name="occupation" placeholder="Enter your main hustle here" tabindex="5"
                        class="form-control">
                      <p id="error2"></p>
                    </div>
                  </div>
                </div>
                <div class="row call-to-action">
                  <div class="col-xs-12">
                    <a class="btn btn-back">Go back</a>
                    <a id="complete2" class="btn btn-orange btn-next">Next</a>
                  </div>
                </div>
              </div>
            </fieldset>
            <fieldset>
              <!-- Side Hustle -->
              <div id="step-side-hustle" class="slider-step step" data-back-to="step-main-hustle">
                <div class="row">
                  <div class="col-12 col-sm-6 ">
                    <div class="file-upload-wrapper">
                      <h3>Side hustle</h3>
                      <div class="image-upload">
                        <div id="side-hustle-prev-case">
                          <img id="side-hustle-prev" src="#" alt="Your Side Hustle Image" />
                        </div>
                        <label for="input-file-side-hustle">
                          <div>
                            <img src="./img/icon-upload.png" alt="Upload Icon">
                            <p>Add your image here or <span>browse</span></p>
                          </div>
                        </label>
                        <input type="file" name="side_hustle" id="input-file-side-hustle" class="file-upload"
                          tabindex="6" required />
                      </div>
                      <input type="text" name="addon" placeholder="Enter your side hustle here" tabindex="7"
                        class="form-control">
                      <p id="error3"></p>
                    </div>
                  </div>
                </div>
                <div class="row call-to-action">
                  <div class="col-xs-12">
                    <a class="btn btn-back">Go back</a>
                    <input id="create-image" name="btn_insert" type='submit' value='Complete' tabindex="6"
                      class="btn btn-orange" />
                  </div>
                </div>
              </div>
            </fieldset>

            <div class="clear"></div>
          </form>
        </div>
        <!-- Offset -->
      </div>
    </div>
  </section>

  <!--jQuery first-->
  <script type="text/javascript" src="./js/jquery-3.2.1.min.js"></script>
  <script type="text/javascript" src="./js/jquery-2.1.1.min.js"></script>
  <!-- jQuery Ui -->
  <script type="text/javascript" src="./js/jquery-ui.min.js"></script>
  <!-- jQuery migrate -->
  <script src="http://code.jquery.com/jquery-migrate-1.4.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="./js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="./js/bootstrap.min.js"></script>
  <!-- html2canvas Javascript -->
  <script type="text/javascript" src="./js/html2canvas.js"></script>
  <!-- custom Javascript -->
  <script type="text/javascript" src="./js/main.js"></script>
</body>

</html>
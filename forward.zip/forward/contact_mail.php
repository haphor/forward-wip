<?php
  $toEmail = "emmanuel.afolabi@anakle.com";
  $subject = "Internship Application";
  $mailHeaders = "From: " . $_POST["firstName"] . " " . $_POST["lastName"] . "<". $_POST["userEmail"] .">\r\n";
  $message = "Name: " . $_POST["firstName"] . " " . $_POST["lastName"] . ">\r\n" . "Email: " . $_POST["email"] . ">\r\n" . "Phone: " . $_POST["phone"] . ">\r\n" . "LinkedIn:" . $_POST["linkedIn"] .">\r\n" . "Portfolio:" . $_POST["portfolio"] .">\r\n" . "Message:" . $_POST["message"] .">\r\n" . "Question:" . $_POST["question"] .">\r\n";
  if(mail($toEmail, $subject, $message, $mailHeaders)) {
    print "<p class='success'>Application Sent.</p>";
  } else {
    print "<p class='Error'>Problem in Sending Mail.</p>";
  }
?>